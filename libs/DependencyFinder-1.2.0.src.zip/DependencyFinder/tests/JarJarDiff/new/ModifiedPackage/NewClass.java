package ModifiedPackage;

public class NewClass {
}
