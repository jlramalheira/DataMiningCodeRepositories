package ModifiedPackage;

public interface NewInterface {
}
