package ModifiedPackage;

public interface UndeprecatedInterface {
}
