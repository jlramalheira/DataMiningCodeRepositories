package ModifiedPackage;

/**
 *  @deprecated
 */
public class DeprecatedClass {
}
