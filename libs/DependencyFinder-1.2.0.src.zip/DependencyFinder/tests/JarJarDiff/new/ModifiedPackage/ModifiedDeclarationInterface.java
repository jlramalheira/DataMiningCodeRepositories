package ModifiedPackage;

public interface ModifiedDeclarationInterface extends Cloneable {
}
