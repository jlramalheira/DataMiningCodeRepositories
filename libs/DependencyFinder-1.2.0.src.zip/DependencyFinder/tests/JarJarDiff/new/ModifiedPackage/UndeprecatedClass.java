package ModifiedPackage;

public class UndeprecatedClass {
}
