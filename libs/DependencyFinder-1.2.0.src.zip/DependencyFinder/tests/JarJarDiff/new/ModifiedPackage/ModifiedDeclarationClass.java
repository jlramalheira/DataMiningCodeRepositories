package ModifiedPackage;

public class ModifiedDeclarationClass implements Cloneable {
}
