package ModifiedPackage;

/**
 *  @deprecated
 */
public interface DeprecatedInterface {
}
