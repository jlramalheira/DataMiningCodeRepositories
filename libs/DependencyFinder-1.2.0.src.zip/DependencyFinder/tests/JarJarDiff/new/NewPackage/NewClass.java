package NewPackage;

public class NewClass {
}
