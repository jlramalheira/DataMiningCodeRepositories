package UnmodifiedPackage;

public class UnmodifiedClass {
    public int unmodifiedField;

    /**
     *  Unmodified Constructor
     */
    public UnmodifiedClass() {
    }
    
    public void unmodifiedMethod() {
    }
}
