package UnmodifiedPackage;

public interface UnmodifiedInterface {
    public static final int unmodifiedField = 0;

    public void unmodifiedMethod();
}
