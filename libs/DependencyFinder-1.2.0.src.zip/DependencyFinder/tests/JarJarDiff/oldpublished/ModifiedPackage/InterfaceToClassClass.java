package ModifiedPackage;

public interface InterfaceToClassClass {}
