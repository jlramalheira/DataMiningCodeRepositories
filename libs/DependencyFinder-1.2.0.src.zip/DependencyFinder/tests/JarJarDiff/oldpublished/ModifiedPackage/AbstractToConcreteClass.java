package ModifiedPackage;

public abstract class AbstractToConcreteClass {}
