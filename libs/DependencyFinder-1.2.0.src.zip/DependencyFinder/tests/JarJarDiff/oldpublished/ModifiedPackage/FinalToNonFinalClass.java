package ModifiedPackage;

public final class FinalToNonFinalClass {}
