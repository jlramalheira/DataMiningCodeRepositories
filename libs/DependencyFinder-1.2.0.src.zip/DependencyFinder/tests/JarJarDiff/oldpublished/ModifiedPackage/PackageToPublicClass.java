package ModifiedPackage;

class PackageToPublicClass {}
