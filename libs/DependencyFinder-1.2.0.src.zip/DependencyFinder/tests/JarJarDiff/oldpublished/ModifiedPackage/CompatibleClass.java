package ModifiedPackage;

public final class CompatibleClass {
    public void incompatibleMethod() {}
}
