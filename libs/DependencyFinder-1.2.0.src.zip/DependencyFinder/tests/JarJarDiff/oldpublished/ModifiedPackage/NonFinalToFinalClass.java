package ModifiedPackage;

public class NonFinalToFinalClass {}
