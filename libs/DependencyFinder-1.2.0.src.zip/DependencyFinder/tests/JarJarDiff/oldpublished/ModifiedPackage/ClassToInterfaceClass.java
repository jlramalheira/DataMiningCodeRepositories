package ModifiedPackage;

public class ClassToInterfaceClass {}
