package ModifiedPackage;

public class ConcreteToAbstractClass {}
