package ModifiedPackage;

public class ImplementsToDifferentImplementsClass implements UnmodifiedPackage.AnInterface {}
