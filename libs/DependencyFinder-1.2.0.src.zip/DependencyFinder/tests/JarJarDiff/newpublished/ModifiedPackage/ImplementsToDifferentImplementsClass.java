package ModifiedPackage;

public class ImplementsToDifferentImplementsClass implements UnmodifiedPackage.AnotherInterface {}
