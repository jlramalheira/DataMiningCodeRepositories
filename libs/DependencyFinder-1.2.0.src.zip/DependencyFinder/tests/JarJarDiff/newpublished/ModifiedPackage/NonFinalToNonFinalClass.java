package ModifiedPackage;

public class NonFinalToNonFinalClass {}
