package ModifiedPackage;

public class AbstractToConcreteClass {}
