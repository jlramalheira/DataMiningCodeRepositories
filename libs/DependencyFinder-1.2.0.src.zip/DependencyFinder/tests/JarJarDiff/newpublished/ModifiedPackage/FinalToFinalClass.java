package ModifiedPackage;

public final class FinalToFinalClass {}
