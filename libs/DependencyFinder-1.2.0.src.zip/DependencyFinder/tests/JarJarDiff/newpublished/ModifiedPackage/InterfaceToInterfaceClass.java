package ModifiedPackage;

public interface InterfaceToInterfaceClass {}
