package ModifiedPackage;

public abstract class ConcreteToAbstractClass {}
