package ModifiedPackage;

public class ImplementsToSameImplementsClass implements UnmodifiedPackage.AnInterface {}
