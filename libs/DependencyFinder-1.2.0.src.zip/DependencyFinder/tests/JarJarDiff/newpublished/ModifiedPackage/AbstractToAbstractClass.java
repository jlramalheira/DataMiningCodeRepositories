package ModifiedPackage;

public abstract class AbstractToAbstractClass {}
