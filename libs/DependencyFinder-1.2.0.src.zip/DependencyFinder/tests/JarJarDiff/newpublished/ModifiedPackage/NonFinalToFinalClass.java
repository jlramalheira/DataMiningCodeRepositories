package ModifiedPackage;

public final class NonFinalToFinalClass {}
