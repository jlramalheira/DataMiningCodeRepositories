package ModifiedPackage;

class PublicToPackageClass {}
