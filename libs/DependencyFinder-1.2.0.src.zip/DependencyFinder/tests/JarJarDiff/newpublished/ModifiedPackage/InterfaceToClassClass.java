package ModifiedPackage;

public class InterfaceToClassClass {}
