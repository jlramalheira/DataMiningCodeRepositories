package ModifiedPackage;

public class ExtendsToDifferentExtendsClass extends UnmodifiedPackage.AnotherClass {}
