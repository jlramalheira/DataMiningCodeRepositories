package ModifiedPackage;

public class ExtendsToSameExtendsClass extends UnmodifiedPackage.AClass {}
