package ModifiedPackage;

public class FinalToNonFinalClass {}
