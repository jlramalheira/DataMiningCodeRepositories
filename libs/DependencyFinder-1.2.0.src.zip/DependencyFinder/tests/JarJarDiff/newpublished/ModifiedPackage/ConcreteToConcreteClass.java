package ModifiedPackage;

public class ConcreteToConcreteClass {}
