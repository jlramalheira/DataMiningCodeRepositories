package ModifiedPackage;

public class CompatibleClass {
    public final void incompatibleMethod() {}
}
