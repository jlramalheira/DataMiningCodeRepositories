package ModifiedPackage;

public interface ClassToInterfaceClass {}
