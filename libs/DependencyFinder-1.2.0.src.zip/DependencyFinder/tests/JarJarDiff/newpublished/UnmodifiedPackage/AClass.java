package UnmodifiedPackage;

public class AClass {}
