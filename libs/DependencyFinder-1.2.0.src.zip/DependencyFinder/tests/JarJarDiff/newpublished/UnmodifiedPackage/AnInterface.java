package UnmodifiedPackage;

public interface AnInterface {}
