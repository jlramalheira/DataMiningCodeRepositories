package UnmodifiedPackage;

public interface AnotherInterface {}
