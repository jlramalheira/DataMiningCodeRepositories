package RemovedPackage;

public class RemovedClass {
}
