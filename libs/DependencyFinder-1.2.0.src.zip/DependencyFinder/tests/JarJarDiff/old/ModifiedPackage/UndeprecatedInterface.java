package ModifiedPackage;

/**
 *  @deprecated
 */
public interface UndeprecatedInterface {
}
