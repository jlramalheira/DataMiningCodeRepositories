package ModifiedPackage;

public class RemovedClass {
}
