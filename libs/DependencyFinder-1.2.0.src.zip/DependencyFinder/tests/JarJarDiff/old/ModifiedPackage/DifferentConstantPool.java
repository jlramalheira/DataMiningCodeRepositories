package ModifiedPackage;

public class DifferentConstantPool {
    public void callingMovedMethodRefInfo() {
	movedMethodRefInfo();
    }

    public void movedMethodRefInfo() {
    }
}
