package ModifiedPackage;

/**
 *  @deprecated
 */
public class UndeprecatedClass {
}
