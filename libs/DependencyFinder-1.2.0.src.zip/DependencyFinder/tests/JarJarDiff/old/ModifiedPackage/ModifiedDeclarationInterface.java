package ModifiedPackage;

public interface ModifiedDeclarationInterface {
}
