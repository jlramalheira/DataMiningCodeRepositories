package ModifiedPackage;

public interface RemovedInterface {
}
