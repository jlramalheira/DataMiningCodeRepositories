package ModifiedPackage;

public interface DeprecatedInterface {
}
