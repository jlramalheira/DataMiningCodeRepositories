package ModifiedPackage;

public class ModifiedDeclarationClass {
}
