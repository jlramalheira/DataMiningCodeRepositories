package ModifiedPackage;

public class DeprecatedClass {
}
