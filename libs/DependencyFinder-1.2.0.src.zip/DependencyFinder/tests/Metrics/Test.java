public class Test {
    public void onewordmethodname() {}
    public void twowordsMethodname() {}
    public void threeWordsMethodname() {}
    public void methodNameWithEndingTLA() {}
    public void tlaAtTheBeginingOfMethodName() {}
    public void methodNameWithTLAInTheMiddle() {}
    public void methodWithParameter(String s) {}
    public void methodWithParameters(String s1, int i, String s2) {}
}
