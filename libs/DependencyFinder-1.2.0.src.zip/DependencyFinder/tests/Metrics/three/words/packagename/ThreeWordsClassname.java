package three.words.packagename;

public class ThreeWordsClassname {}
