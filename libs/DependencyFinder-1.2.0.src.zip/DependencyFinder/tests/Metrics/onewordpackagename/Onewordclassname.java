package onewordpackagename;

public class Onewordclassname {}
