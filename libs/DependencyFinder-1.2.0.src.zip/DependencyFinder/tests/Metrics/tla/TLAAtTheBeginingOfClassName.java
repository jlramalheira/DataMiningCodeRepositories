package tla;

public class TLAAtTheBeginingOfClassName {}
