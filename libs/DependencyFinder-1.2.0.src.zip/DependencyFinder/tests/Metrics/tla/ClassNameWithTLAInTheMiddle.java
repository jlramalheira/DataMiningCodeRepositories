package tla;

public class ClassNameWithTLAInTheMiddle {}
