package tla;

public class ClassNameWithEndingTLA {}
