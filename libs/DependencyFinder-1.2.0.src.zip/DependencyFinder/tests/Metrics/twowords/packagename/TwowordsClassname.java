package twowords.packagename;

public class TwowordsClassname {}
